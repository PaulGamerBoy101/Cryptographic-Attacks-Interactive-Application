


const scriptsInEvents = {

	async Startscreenevents_Event10(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async GameEvents_Event11(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async AboutScreenEvents_Event6(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async RedhouseEvents_Event6(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async Game2Events_Event11(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async YellowHouseEvents_Event6(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async PinkHouseEvents_Event6(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async OrangeHouseEvents_Event6(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async PurpleHouseEvents_Event6(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async MintHouseEvents_Event6(runtime, localVars)
	{
		document.body.style.cursor = "none";
	},

	async Game3Events_Event5(runtime, localVars)
	{
		document.body.style.cursor = "auto";
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

